import java.util.*;
import javax.swing.*;
import java.lang.Math;
public abstract class Piece{
   protected int a;
   protected int b;
   protected int col;
   public static String name = "Piece";
   public boolean justMoved;
   private static int[] lastMoved = new int[]{1,1};
   public boolean enPassant;
   protected ImageIcon piece;
   public boolean firstMove;
   public boolean castling;
   
   public Piece(int a, int b, int col)
   {
      firstMove=true;
      this.a=a;
      this.b=b;
      this.col=col;
   }
   //every piece must move
   //public abstract void move();
   
   //check if piece can move legally
   //public abstract boolean canMove();
   
   //if piece is captured
  // public abstract void captured();
   
   
   public abstract Stack<int[]> getLegalSquares();
   public abstract ImageIcon getImage();
   
   public void move(int a, int b)
   {
           
   
      if(lastMoved[0]!=-1)
      {
         Chessboard.board[lastMoved[0]][lastMoved[1]].justMoved=false;
      }
      
      Piece x = Chessboard.board[this.a][this.b];
      Chessboard.board[this.a][this.b]=null;
      Chessboard.board[a][b]=x;
      int oldA=this.a;  
      int oldB=this.b;    
      this.a=a;
      this.b=b;
      if(Chessboard.board[a][b].name.equals("Pawn")){
         if(Chessboard.board[a][b].enPassant){
            Chessboard.board[oldA][b] = null;
         }
      }
      else if(Chessboard.board[a][b].name.equals("King")){
         if(castling){
            if(Math.abs(oldB-this.b)==2)
            {
            
               if(this.b>3)
               {
                  Chessboard.board[this.a][this.b-1]=Chessboard.board[this.a][this.b+1];
                  Chessboard.board[this.a][this.b+1]=null;
               }
               else
               {
                  Chessboard.board[this.a][this.b+1]=Chessboard.board[this.a][this.b-2];
                  Chessboard.board[this.a][this.b-2]=null;
               }
            }
         }
      }
      if(firstMove)
      {
         justMoved=true;
         firstMove=false;
      }
      
      lastMoved[0]=a;
      lastMoved[1]=b;
      
      
    
      
      
   }

}