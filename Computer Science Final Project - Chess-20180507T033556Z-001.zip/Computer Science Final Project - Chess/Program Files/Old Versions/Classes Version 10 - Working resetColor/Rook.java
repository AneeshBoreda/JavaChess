import java.util.*;
import javax.swing.*;
public class Rook extends Piece{
   String position;

   boolean firstMove;
   public Stack<int[]> availableSquares;
   public ImageIcon piece;
   public Rook(int a, int b, int color){
      super(a,b,color);
      firstMove = true;
      if(color == 0){
         this.piece=new ImageIcon("ChessPieceImages/Blue2R.png");
      }
      else{
         this.piece=new ImageIcon("ChessPieceImages/BlackR.png");
      }
   }
   public boolean check(int a, int b){
      return true;
   }
   public void addSquare(int a, int b){
   }
   public ImageIcon getImage(){
      return piece;
   }
   public Stack<int[]> getLegalSquares(){
      return availableSquares;
   }
}