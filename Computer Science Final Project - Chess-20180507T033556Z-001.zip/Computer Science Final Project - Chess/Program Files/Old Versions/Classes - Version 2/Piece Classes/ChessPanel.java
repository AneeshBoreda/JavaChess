//Name______________________________ Date_____________
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class ChessPanel extends JPanel
{
   private JLabel label1, label2;
   private JTextField box;
   private int number, count;
   public ChessPanel()
   {
      setLayout(new GridLayout(8, 8));
      number = 37;     //number gets 37
      count = 0;
      JButton[][] board = new JButton[8][8];
      for(int i = 0; i < 8; i++){
      
   
   }
   private class Listener1 implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         number = Integer.parseInt(box.getText());
         label1.setText(Integer.toString(number));
         count = 0;
         label2.setText("Iterations: " + Integer.toString(count));
      }
   }
   private class Listener2 implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         if(number % 2 == 0){
            number/=2;
         }
         else{
            number = 3 * number + 1;
         }
         label1.setText(Integer.toString(number));
         count++;
         label2.setText("Iterations: " + Integer.toString(count));
      }
   }
   private class Listener3 implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         System.exit(0);
      }
   }
}