import java.util.*;
import javax.swing.*;
public class Queen extends Piece{
   String position;
   int color;
   boolean firstMove;
   int[][] availableSquares;
   ImageIcon piece;
   public Queen(int a, int b, int color){
      position = Integer.toString(a) + " " + Integer.toString(b);
      this.color = color;
      firstMove = true;
      if(color == 0){
         piece=new ImageIcon("ChessPieceImages/Blue2Q.png");
      }
      else{
         piece=new ImageIcon("ChessPieceImages/BlackQ.png");
      }
   }
   public boolean check(int a, int b){
      return true;
   }
   public void addSquare(int a, int b){
   }
   public int[][]getLegalSquares(){
      return availableSquares;
   }
}