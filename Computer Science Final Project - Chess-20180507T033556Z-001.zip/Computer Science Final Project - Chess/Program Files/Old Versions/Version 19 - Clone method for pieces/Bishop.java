import java.util.*;
import javax.swing.*;
public class Bishop extends Piece{ 

   public Stack<int[]> availableSquares;
   public ImageIcon piece;
   public Bishop(int a, int b, int color){
      super(a,b,color);
      name = "Bishop";
      firstMove = true;
      if(color == 0){
         this.piece=new ImageIcon("ChessPieceImages/Blue2B.png");
      }
      else{
         this.piece=new ImageIcon("ChessPieceImages/BlackB.png");
      }
   }
   public void clonePiece(Piece x)
   {
      this.a = x.a;
      this.b = x.b;
      this.firstMove=x.firstMove;
      this.col=x.col;
      this.piece=x.piece;
      this.name="Bishop";
      this.justMoved = x.justMoved;
   }
   public boolean check(int a, int b){
      return true;
   }
   public void addSquare(int a, int b){
   }
   public ImageIcon getImage(){
      return piece;
   }
   public Stack<int[]> getAttackedSquares(){
      availableSquares=new Stack<>();
      int l;
      for(int k = 1; k < 8; k++){
         l = k;
         if(a+k > 7 || b+l > 7){
            break;
         }
         if(Chessboard.board[a+k][b+l] != null ){
            availableSquares.push(new int[]{a+k, b+l});
            
            if(!Chessboard.board[a+k][b+l].name.equals("King") || Chessboard.board[a+k][b+l].col==this.col)
            {
            break;
            }
            else{
               availableSquares.pop();
            }
         }
         availableSquares.push(new int[]{a+k, b+l});
      }
      for(int k = 1; k < 8; k++){
         l = k;
         if(a-k < 0 || b-l < 0){
            break;
         }
         if(Chessboard.board[a-k][b-l] != null){
            availableSquares.push(new int[]{a-k, b-l});
            if(!Chessboard.board[a-k][b-l].name.equals("King") || Chessboard.board[a-k][b-l].col==this.col)
            {
            break;
            }
            else{
               availableSquares.pop();
            }
         }

         availableSquares.push(new int[]{a-k, b-l});
      }
      for(int k = 1; k < 8; k++){
         l = -k;
         if(a+k > 7 || b+l < 0){
            break;
         }
         if(Chessboard.board[a+k][b+l] != null){
            availableSquares.push(new int[]{a+k, b+l});
            if(!Chessboard.board[a+k][b+l].name.equals("King") || Chessboard.board[a+k][b+l].col==this.col)
            {
            break;
            }
            else{
               availableSquares.pop();
            }
            
         }
        
         availableSquares.push(new int[]{a+k, b+l});
      }
      for(int k = 1; k < 8; k++){
         l = -k;
         if(a-k < 0 || b-l > 7){
            break;
         }
         if(Chessboard.board[a-k][b-l] != null){
            availableSquares.push(new int[]{a-k, b-l});
            if(!Chessboard.board[a-k][b-l].name.equals("King") || Chessboard.board[a-k][b-l].col==this.col)
            {
            break;
            }
            else{
               availableSquares.pop();
            }
         }
         availableSquares.push(new int[]{a-k, b-l});
      }
      return availableSquares;
   }
   public Stack<int[]> getLegalSquares(){
      availableSquares = new Stack<int[]>();
      int l;
      for(int k = 1; k < 8; k++){
         l = k;
         if(a+k > 7 || b+l > 7){
            break;
         }
         if(Chessboard.board[a+k][b+l] != null && Chessboard.board[a+k][b+l].col == -1*(col-1)){
            availableSquares.push(new int[]{a+k, b+l});
            break;
         }
         else if(Chessboard.board[a+k][b+l] != null){
            break;
         }
         availableSquares.push(new int[]{a+k, b+l});
      }
      for(int k = 1; k < 8; k++){
         l = k;
         if(a-k < 0 || b-l < 0){
            break;
         }
         if(Chessboard.board[a-k][b-l] != null && Chessboard.board[a-k][b-l].col == -1*(col-1)){
            availableSquares.push(new int[]{a-k, b-l});
            break;
         }
         else if(Chessboard.board[a-k][b-l] != null){
            break;
         }
         availableSquares.push(new int[]{a-k, b-l});
      }
      for(int k = 1; k < 8; k++){
         l = -k;
         if(a+k > 7 || b+l < 0){
            break;
         }
         if(Chessboard.board[a+k][b+l] != null && Chessboard.board[a+k][b+l].col == -1*(col-1)){
            availableSquares.push(new int[]{a+k, b+l});
            break;
         }
         else if(Chessboard.board[a+k][b+l] != null){
            break;
         }
         availableSquares.push(new int[]{a+k, b+l});
      }
      for(int k = 1; k < 8; k++){
         l = -k;
         if(a-k < 0 || b-l > 7){
            break;
         }
         if(Chessboard.board[a-k][b-l] != null && Chessboard.board[a-k][b-l].col == -1*(col-1)){
            availableSquares.push(new int[]{a-k, b-l});
            break;
         }
         else if(Chessboard.board[a-k][b-l] != null){
            break;
         }
         availableSquares.push(new int[]{a-k, b-l});
      }
      return availableSquares;
   }
      
}
