import java.util.*;
import javax.swing.*;
import java.lang.*;
public class King extends Piece{
   String position;

   boolean firstMove;
   public Stack<int[]> availableSquares;
   public ImageIcon piece;
   public King(int a, int b, int color){
      super(a,b,color);
      name="King";
      firstMove = true;
      if(color == 0){
         this.piece=new ImageIcon("ChessPieceImages/Blue2K.png");
      }
      else{
         this.piece=new ImageIcon("ChessPieceImages/BlackK.png");
      }
   }
   public boolean check(int a, int b){
      return true;
   }
   public void addSquare(int a, int b){
   }
   public ImageIcon getImage(){
      return piece;
   }
   public Stack<int[]> getLegalSquares(){
      availableSquares=new Stack<>();
      int k = Math.max(0,a-1);
      int l=  Math.min(7,a+1);
      int m=  Math.max(0,b-1);
      int n=  Math.min(7,b+1);


      for(int i = k; i<=l; i++)
      {  
         for(int j = m; j<=n; j++)
         {
            
            if(i==a && j==b){
               continue;
            }
            if(Chessboard.board[i][j]==null)
            {
               availableSquares.push(new int[]{i,j});
            }
            else if(Chessboard.board[i][j].col != this.col)
            {
               availableSquares.push(new int[]{i,j});
            }
         }
      
      }
      if(this.firstMove)
      {
         if(Chessboard.board[this.a][this.b+3] != null && Chessboard.board[this.a][this.b+2]==null
         && Chessboard.board[this.a][this.b+1]==null )
         {
             if(Chessboard.board[this.a][this.b+3].firstMove)
             {
              availableSquares.push(new int[]{this.a, this.b+2});
              castling=true;
             }
         }
         if(Chessboard.board[this.a][this.b-4] != null && Chessboard.board[this.a][this.b-2]==null
         && Chessboard.board[this.a][this.b-1]==null && Chessboard.board[this.a][this.b-3]==null
 )
         {
             if(Chessboard.board[this.a][this.b-4].firstMove)
             {
              availableSquares.push(new int[]{this.a, this.b-2});
              castling=true;
             }
         }
      }
      
      return availableSquares;
   }
}