import javax.swing.JFrame;

public class ChessDriver{
   public static void main(String[] args)
   {
      JFrame frame = new JFrame("Chess");
      frame.setSize(400, 400);
      frame.setLocation(0, 0);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setContentPane(new ChessPanel());
      frame.setVisible(true);
   }
}