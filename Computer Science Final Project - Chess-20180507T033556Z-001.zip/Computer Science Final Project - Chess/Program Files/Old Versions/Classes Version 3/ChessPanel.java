import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
public class ChessPanel extends JPanel
{
   private JLabel label1, label2;
   private JTextField box;
   private int number, count;
   private Color col;
   public static JButton[][] board;
   public static Piece[][] pieces;
   public static Chessboard chessboard;
   public ChessPanel()
   {  pieces=new Piece[8][8];
      setLayout(new GridLayout(8, 8));
      count = 0;
      board = new JButton[8][8];
      for(int i = 0; i < 8; i++){
         pieces[1][i]=new Pawn(1,i,1);
      }
      for(int i = 0; i < 8; i++){
         pieces[6][i]=new Pawn(6,i,0);
      }
      chessboard=new Chessboard(pieces);
      for(int i = 0; i < 8; i++){
         for(int j = 0; j < 8; j++){
            board[i][j]=new JButton();
            board[i][j].addActionListener(new Listener(i,j));
            //Integer.toString(i*8+j+1)Integer.toString(i*8+j+1)
            board[i][j].setFocusPainted(false);
            
            if((i+j)%2==0){
               col=Color.WHITE;
            }
            else{
               col=Color.BLACK;
            }
            if (pieces[i][j]!=null)
            {
               ImageIcon icon=((Pawn) pieces[i][j]).piece;
               board[i][j].setIcon(icon);
            }
            board[i][j].setBackground(col);
            
            add(board[i][j]);
         }      
      }
   }
   private class Listener implements ActionListener{
      private int[] pos;
      public Listener(int a, int b){
        pos=new int[2];
        pos[0]=a;
        pos[1]=b;
        
      }
      
      public void actionPerformed(ActionEvent e)
      {
         col=Color.ORANGE;
         board[pos[0]][pos[1]].setBackground(col);
      }
   }
   
}
