import java.util.*;
import java.awt.*;


public class Chessboard{
   public static Piece[][] board;
   public static int[] clickLoc;
   public static boolean pieceSelected;
   public static Stack<int[]> legalSquares;
   public static int[][]legalSquaresArr;
   public static int turn=0;
   public Chessboard(){
     // board=x;
   
   }
   public static Piece[][] Input(int a, int b)
   {
     
      if(clickLoc==null&&getPiece(a,b)!=null)
      {
         if(getPiece(a,b).col==turn){
            pieceSelected=true;
            clickLoc = new int[] {a,b};
            ChessPanel.board[a][b].setBackground(ChessPanel.selectedCol);
            legalSquares=board[a][b].getLegalSquares();
            legalSquaresArr=new int[legalSquares.size()][2];
            int count = 0;
            while(!legalSquares.empty())
            {
               legalSquaresArr[count]=legalSquares.pop();
               count++;
            }
            highlightLegalSquares(legalSquaresArr);
         }
         else
         {
            if(turn==0)
            {
               InfoPanel.setMessageText("It is white's turn. Please move a white piece");
            }
            else
            {
               InfoPanel.setMessageText("It is black's turn. Please move a black piece");

            }
         }
         
         
      }
      else if (pieceSelected)
      {
         if(a==clickLoc[0] && b==clickLoc[1])
         {
            ChessPanel.resetColor(clickLoc[0],clickLoc[1]);
            pieceSelected=false;
            clickLoc=null;
            resetLegalSquares(legalSquaresArr);
         
         }
         else
         {
            boolean contains = false;
            for(int[] i: legalSquaresArr){
               if(a == i[0] && b == i[1]){
                  contains = true;
                  break;
               }
            }
            if(contains == true){
               board[clickLoc[0]][clickLoc[1]].move(a,b);
               ChessPanel.resetColor(clickLoc[0],clickLoc[1]);
               ChessPanel.updateBoard();
               clickLoc=null;
               pieceSelected=false;
               resetLegalSquares(legalSquaresArr);
               if(turn==0)
               {
                  turn=1;
                  InfoPanel.resetMessageText();
               }
               else
               {
                  turn=0;
                  InfoPanel.resetMessageText();
               }
            }
            else{
               InfoPanel.setMessageText("Please choose one of the squares highlighted green.");
                          }
         }
      }
      return board;
   }
   public static Piece getPiece(int a, int b)
   {
      return board[a][b];
   }
   public static void highlightLegalSquares(int[][]legalSquares)
   {
      
      for(int[]x:legalSquares)

      {  
         ChessPanel.board[x[0]][x[1]].setBackground(ChessPanel.legalCol);
      }  
   }
   public static void resetLegalSquares(int[][]legalSquares)
   {
      
      
      for(int[]x:legalSquares)
      {
         ChessPanel.resetColor(x[0],x[1]);
      }  
   }
  
}