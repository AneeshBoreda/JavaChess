import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
public class ChessPanel extends JPanel
{
   private JLabel label1, label2;
   private JTextField box;
   private static int number, count;
   private static Color col;
   public static Color selectedCol;
   public static Color legalCol;
   public static JButton[][] board;
   public static Piece[][] pieces;
   
   public ChessPanel()
   {  pieces=new Piece[8][8];
      setLayout(new GridLayout(8, 8));
      count = 0;
      board = new JButton[8][8];
      selectedCol=new Color(255,189,66);
      legalCol=new Color(0,255,0);
      
      //This section creates the chessboard with all the chess pieces in the default position
      for(int i = 0; i < 8; i++){
         //Black pawns
         pieces[1][i]=new Pawn(1,i,1);
      }
      for(int i = 0; i < 8; i++){
         //White pawns
         pieces[6][i]=new Pawn(6,i,0);
      }
      //Other white pieces
      pieces[7][0]= new Rook(7,0,0);
      pieces[7][1]= new Knight(7,1,0);
      pieces[7][2]= new Bishop(7,2,0);
      pieces[7][3]= new Queen(7,3,0);
      pieces[7][4]= new King(7,4,0);
      pieces[7][5]= new Bishop(7,5,0);
      pieces[7][6]= new Knight(7,6,0);
      pieces[7][7]= new Rook(7,7,0);
      //Other black pieces
      pieces[0][0]= new Rook(0,0,1);
      pieces[0][1]= new Knight(0,1,1);
      pieces[0][2]= new Bishop(0,2,1);
      pieces[0][3]= new Queen(0,3,1);
      pieces[0][4]= new King(0,4,1);
      pieces[0][5]= new Bishop(0,5,1);
      pieces[0][6]= new Knight(0,6,1);
      pieces[0][7]= new Rook(0,7,1);
      
      Chessboard.board2=pieces;
      for(int i = 0; i < 8; i++){
         for(int j = 0; j < 8; j++){
            board[i][j]=new JButton();
            board[i][j].addActionListener(new Listener(i,j));
            //Integer.toString(i*8+j+1)Integer.toString(i*8+j+1)
            board[i][j].setFocusPainted(false);
            
            if((i+j)%2==0){
               col=Color.WHITE;
            }
            else{
               col=Color.BLACK;
            }
            if (pieces[i][j]!=null)
            {
               ImageIcon icon= Chessboard.getPiece(i,j).getImage();
               board[i][j].setIcon(icon);
            }
            board[i][j].setBackground(col);
            
            add(board[i][j]);
         }      
      }
      //gets legal squares
      for(int i = 0; i < 8; i++){
         for(int j = 0; j < 8; j++){
            //not nothing
            if(pieces[i][j] != null){
               //pawn - only 1 square forward, no en passant, no promotion yet
               if(pieces[i][j].getName().equals("Pawn")){
                  if(pieces[i][j].col == 0){
                     pieces[i][j].addSquare(i-1, j, 0);
                  }else{
                     pieces[i][j].addSquare(i+1, j, 0);
                  }
               }         
               //knight
               if(pieces[i][j].getName().equals("Knight")){
                  count = 0;
                  for(int k = -2; k < 3; k+=4){
                     for(int l = -1; l < 2; l+=2){
                        if((i-l > -1 && j-k > -1) && (i-l < 8 && j-k < 8)){
                           if(pieces[i-l][j-k] == null || pieces[i-l][j-k].col == -1*(pieces[i][j].col-1)){
                              count++;
                              pieces[i][j].addSquare(i-l, j-k, count-1);
                           }
                        }
                        if((i-k > -1 && j-l > -1) && (i-k < 8 && j-l < 8)){
                           if(pieces[i-k][j-l] == null || pieces[i-k][j-l].col == -1*(pieces[i][j].col-1)){
                              count++;
                              pieces[i][j].addSquare(i-k, j-l, count-1);
                           }
                        }
                     }
                  }
               }
            }
         }
      } 
   }
   public static void updateBoard()
   {  
      System.out.println("updateBoard");
      for(int i = 0; i < 8; i++){
         for(int j = 0; j < 8; j++){
            if((i+j) % 2 == 0){
               col = Color.WHITE;
            }else{
               col = Color.BLACK;
            }
            if (pieces[i][j]!=null)
            {
               ImageIcon icon= Chessboard.getPiece(i,j).getImage();
               board[i][j].setIcon(icon);
               pieces[i][j].clearSquares();
            }
            else
            {
               board[i][j].setIcon(null);
            }
            board[i][j].setBackground(col);
         }
      }
       //gets legal squares
      for(int i = 0; i < 8; i++){
         for(int j = 0; j < 8; j++){
            //not nothing
            if(pieces[i][j] != null){
               //pawn - only 1 square forward, no en passant, no promotion yet
               if(pieces[i][j].getName().equals("Pawn")){
                  if(pieces[i][j].col == 0){
                     pieces[i][j].addSquare(i-1, j, 0);
                  }else{
                     pieces[i][j].addSquare(i+1, j, 0);
                  }
               }         
               //knight
               if(pieces[i][j].getName().equals("Knight")){
                  count = 0;
                  for(int k = -2; k < 3; k+=4){
                     for(int l = -1; l < 2; l+=2){
                        if((i-l > -1 && j-k > -1) && (i-l < 8 && j-k < 8)){
                           if(pieces[i-l][j-k] == null || pieces[i-l][j-k].col == -1*(pieces[i][j].col-1)){
                              count++;
                              pieces[i][j].addSquare(i-l, j-k, count-1);
                           }
                        }
                        if((i-k > -1 && j-l > -1) && (i-k < 8 && j-l < 8)){
                           if(pieces[i-k][j-l] == null || pieces[i-k][j-l].col == -1*(pieces[i][j].col-1)){
                              count++;
                              pieces[i][j].addSquare(i-k, j-l, count-1);
                           }
                        }
                     }
                  }
               }
               //bishop
               if(pieces[i][j].getName().equals("Bishop")){
                  count = 0;
                  int l;
                  for(int k = 1; k < 8; k++){
                     l = k;
                     if(i+k > 7 || j+l > 7){
                        break;
                     }
                     if(pieces[i+k][j+l] != null && pieces[i+k][j+l].col == -1*(pieces[i][j].col-1)){
                        count++;
                        pieces[i][j].addSquare(i+k, j+l, count-1);
                        break;
                     }else if(pieces[i+k][j+l] != null){
                        break;
                     }
                     count++;
                     pieces[i][j].addSquare(i+k, j+l, count-1);
                  }
                  for(int k = 1; k < 8; k++){
                     l = k;
                     if(i-k < 0 || j-l < 0){
                        break;
                     }
                     System.out.println(j-l);
                     if(pieces[i-k][j-l] != null && pieces[i-k][j-l].col == -1*(pieces[i][j].col-1)){
                        count++;
                        pieces[i][j].addSquare(i-k, j-l, count-1);
                        break;
                     }else if(pieces[i-k][j-l] != null){
                        break;
                     }
                     count++;
                     pieces[i][j].addSquare(i-k, j-l, count-1);
                  }
                  for(int k = 1; k < 8; k++){
                     l = -k;
                     if(i+k > 7 || j+l < 0){
                        break;
                     }
                     if(pieces[i+k][j+l] != null && pieces[i+k][j+l].col == -1*(pieces[i][j].col-1)){
                        count++;
                        pieces[i][j].addSquare(i+k, j+l, count-1);
                        break;
                     }else if(pieces[i+k][j+l] != null){
                        break;
                     }
                     count++;
                     pieces[i][j].addSquare(i+k, j+l, count-1);
                  }
                  for(int k = 1; k < 8; k++){
                     l = -k;
                     if(i-k < 0 || j-l > 7){
                        break;
                     }
                     if(pieces[i-k][j-l] != null && pieces[i-k][j-l].col == -1*(pieces[i][j].col-1)){
                        count++;
                        pieces[i][j].addSquare(i-k, j-l, count-1);
                        break;
                     }else if(pieces[i-k][j-l] != null){
                        break;
                     }
                     count++;
                     pieces[i][j].addSquare(i-k, j-l, count-1);
                  }
               }
               //rook
               if(pieces[i][j].getName().equals("Rook")){
                  count = 0;
                  for(int k = 1; k < 8; k++){
                     if(i+k > 7){
                        break;
                     }
                     if(pieces[i+k][j] != null && pieces[i+k][j].col == -1*(pieces[i][j].col-1)){
                        count++;
                        pieces[i][j].addSquare(i+k, j, count-1);
                        break;
                     }else if(pieces[i+k][j] != null){
                        break;
                     }
                     count++;
                     pieces[i][j].addSquare(i+k, j, count-1);
                  }
                  for(int k = 1; k < 8; k++){
                     if(i-k < 0){
                        break;
                     }
                     System.out.println(j);
                     if(pieces[i-k][j] != null && pieces[i-k][j].col == -1*(pieces[i][j].col-1)){
                        count++;
                        pieces[i][j].addSquare(i-k, j, count-1);
                        break;
                     }else if(pieces[i-k][j] != null){
                        break;
                     }
                     count++;
                     pieces[i][j].addSquare(i-k, j, count-1);
                  }
                  for(int k = 1; k < 8; k++){
                     if(j+k > 7){
                        break;
                     }
                     if(pieces[i][j+k] != null && pieces[i][j+k].col == -1*(pieces[i][j].col-1)){
                        count++;
                        pieces[i][j].addSquare(i, j+k, count-1);
                        break;
                     }else if(pieces[i][j+k] != null){
                        break;
                     }
                     count++;
                     pieces[i][j].addSquare(i, j+k, count-1);
                  }
                  for(int k = 1; k < 8; k++){
                     if(j-k < 0){
                        break;
                     }
                     if(pieces[i][j-k] != null && pieces[i][j-k].col == -1*(pieces[i][j].col-1)){
                        count++;
                        pieces[i][j].addSquare(i, j-k, count-1);
                        break;
                     }else if(pieces[i][j-k] != null){
                        break;
                     }
                     count++;
                     pieces[i][j].addSquare(i, j-k, count-1);
                  }
               }
               //queen
               if(pieces[i][j].getName().equals("Queen")){
                  count = 0;
                  for(int k = 1; k < 8; k++){
                     if(i+k > 7){
                        break;
                     }
                     if(pieces[i+k][j] != null && pieces[i+k][j].col == -1*(pieces[i][j].col-1)){
                        count++;
                        pieces[i][j].addSquare(i+k, j, count-1);
                        break;
                     }else if(pieces[i+k][j] != null){
                        break;
                     }
                     count++;
                     pieces[i][j].addSquare(i+k, j, count-1);
                  }
                  for(int k = 1; k < 8; k++){
                     if(i-k < 0){
                        break;
                     }
                     System.out.println(j);
                     if(pieces[i-k][j] != null && pieces[i-k][j].col == -1*(pieces[i][j].col-1)){
                        count++;
                        pieces[i][j].addSquare(i-k, j, count-1);
                        break;
                     }else if(pieces[i-k][j] != null){
                        break;
                     }
                     count++;
                     pieces[i][j].addSquare(i-k, j, count-1);
                  }
                  for(int k = 1; k < 8; k++){
                     if(j+k > 7){
                        break;
                     }
                     if(pieces[i][j+k] != null && pieces[i][j+k].col == -1*(pieces[i][j].col-1)){
                        count++;
                        pieces[i][j].addSquare(i, j+k, count-1);
                        break;
                     }else if(pieces[i][j+k] != null){
                        break;
                     }
                     count++;
                     pieces[i][j].addSquare(i, j+k, count-1);
                  }
                  for(int k = 1; k < 8; k++){
                     if(j-k < 0){
                        break;
                     }
                     if(pieces[i][j-k] != null && pieces[i][j-k].col == -1*(pieces[i][j].col-1)){
                        count++;
                        pieces[i][j].addSquare(i, j-k, count-1);
                        break;
                     }else if(pieces[i][j-k] != null){
                        break;
                     }
                     count++;
                     pieces[i][j].addSquare(i, j-k, count-1);
                  }
                  int l;
                  for(int k = 1; k < 8; k++){
                     l = k;
                     if(i+k > 7 || j+l > 7){
                        break;
                     }
                     if(pieces[i+k][j+l] != null && pieces[i+k][j+l].col == -1*(pieces[i][j].col-1)){
                        count++;
                        pieces[i][j].addSquare(i+k, j+l, count-1);
                        break;
                     }else if(pieces[i+k][j+l] != null){
                        break;
                     }
                     count++;
                     pieces[i][j].addSquare(i+k, j+l, count-1);
                  }
                  for(int k = 1; k < 8; k++){
                     l = k;
                     if(i-k < 0 || j-l < 0){
                        break;
                     }
                     System.out.println(j-l);
                     if(pieces[i-k][j-l] != null && pieces[i-k][j-l].col == -1*(pieces[i][j].col-1)){
                        count++;
                        pieces[i][j].addSquare(i-k, j-l, count-1);
                        break;
                     }else if(pieces[i-k][j-l] != null){
                        break;
                     }
                     count++;
                     pieces[i][j].addSquare(i-k, j-l, count-1);
                  }
                  for(int k = 1; k < 8; k++){
                     l = -k;
                     if(i+k > 7 || j+l < 0){
                        break;
                     }
                     if(pieces[i+k][j+l] != null && pieces[i+k][j+l].col == -1*(pieces[i][j].col-1)){
                        count++;
                        pieces[i][j].addSquare(i+k, j+l, count-1);
                        break;
                     }else if(pieces[i+k][j+l] != null){
                        break;
                     }
                     count++;
                     pieces[i][j].addSquare(i+k, j+l, count-1);
                  }
                  for(int k = 1; k < 8; k++){
                     l = -k;
                     if(i-k < 0 || j-l > 7){
                        break;
                     }
                     if(pieces[i-k][j-l] != null && pieces[i-k][j-l].col == -1*(pieces[i][j].col-1)){
                        count++;
                        pieces[i][j].addSquare(i-k, j-l, count-1);
                        break;
                     }else if(pieces[i-k][j-l] != null){
                        break;
                     }
                     count++;
                     pieces[i][j].addSquare(i-k, j-l, count-1);
                  }

               }
            }
         }
      } 
       

      
   }

   private class Listener implements ActionListener{
      private int[] pos;
      public Listener(int a, int b){
         pos=new int[2];
         pos[0]=a;
         pos[1]=b;
         
        
      }
      
      public void actionPerformed(ActionEvent e)
      {
         
         pieces=Chessboard.Input(pos[0],pos[1]);
      }
   }
   
}
