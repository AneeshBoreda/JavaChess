import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
public class ChessPanel extends JPanel
{   
   private JLabel label1, label2;
   private JTextField box;
   private int number, count;
   private static Color col;
   public static Color selectedCol;
   public static Color legalCol;
   public static JButton[][] board;
   public static Piece[][] pieces;
   public ChessPanel(){}
   public static void updateBoard()
   {
      for(int i = 0; i < 8; i++){
         for(int j = 0; j < 8; j++){
            if (pieces[i][j]!=null)
            {
               ImageIcon icon= Chessboard.getPiece(i,j).getImage();
            }
            else{}
         }
      }
   }
   public static void resetColor(int a, int b){}
   private class Listener implements ActionListener
   {
      private int[] pos;
      public Listener(int a, int b)
      {
         pos=new int[2];
         pos[0]=a;
         pos[1]=b;
      }
      public void actionPerformed(ActionEvent e)
      {
         pieces=Chessboard.Input(pos[0],pos[1]);
      }
   }  
}