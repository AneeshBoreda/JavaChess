import javax.swing.*;
import java.io.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;

public class InfoPanel extends JPanel {
   private static JButton[] buttons;  
   private static JLabel label;
   private GridBagLayout g;  
   private static volatile int pieceNum;
   private static int a;
   private static int b;
   private static int turn;

   public InfoPanel() 
   {
      
      buttons=new JButton[4];
      g=new GridBagLayout();
      setLayout(g);
      GridBagConstraints c = new GridBagConstraints();
      label = new JLabel("No Messages to Show");
      label.setFont(new Font("Arial", 1, 18));
      c.insets=new Insets(0,10,0,10);
      c.gridx=0;
      c.gridy=0;
      c.gridwidth = 4;
      c.weighty=0.5;
      c.weightx=1.0;
      add(label, c);
      c.gridwidth=1;
      c.gridy=1;
      c.weighty=0.5;
      c.weightx=1.0;
      c.fill=GridBagConstraints.BOTH;
      for(int i=0; i<4; i++)
      {
         c.gridx=i;
         buttons[i]=new JButton();
         buttons[i].addActionListener(new Listener(i+1));
         buttons[i].setFocusPainted(false);
         buttons[i].setVisible(false);
         add(buttons[i],c);
      }
      
   }
   public static void setInfoMessageText(String st)
   {
      label.setForeground(Color.BLUE.brighter());
      label.setText(st);
      
   }
   public static void setErrorMessageText(String st)
   {
      label.setForeground(Color.RED);
      label.setText(st);
      
   }
   public static void Promotion(int currentTurn, int posA, int posB) 
   {
      a=posA;
      b=posB;
      turn=currentTurn;
      ImageIcon[] pieceImgs;
      if(turn==0)
      {
         ImageIcon Queen= new Queen(0,0,0).getImage();
         ImageIcon Rook= new Rook(0,0,0).getImage();
         ImageIcon Bishop= new Bishop(0,0,0).getImage();
         ImageIcon Knight= new Knight(0,0,0).getImage();
         pieceImgs= new ImageIcon[]{Queen, Rook, Bishop, Knight};
      }
      else
      {
         ImageIcon Queen= new Queen(0,0,1).getImage();
         ImageIcon Rook= new Rook(0,0,1).getImage();
         ImageIcon Bishop= new Bishop(0,0,1).getImage();
         ImageIcon Knight= new Knight(0,0,1).getImage();
         pieceImgs= new ImageIcon[]{Queen, Rook, Bishop, Knight};
      }
   
      for(int i=0; i<4; i++)
      {  
         
         buttons[i].setIcon(pieceImgs[i]);
         buttons[i].setVisible(true);
         
      }
      
      
   
   }
   public static void reset()
   {
      label.setForeground(Color.BLACK);
      label.setText("No Messages to Show");
      for(int i=0; i<4; i++)
      {
         buttons[i].setVisible(false);
      }
      
   }
   private class Listener implements ActionListener{
      private int pos;
      public Listener(int a){
         pos=a;
      }
      
      public void actionPerformed(ActionEvent e)
      {
         if (pos==1)
         {
         Chessboard.board[a][b]=new Queen(a,b,turn);
         }
         else if (pos==2)
         {
         Chessboard.board[a][b]=new Rook(a,b,turn);
         }
         else if (pos==3)
         {
         Chessboard.board[a][b]=new Bishop(a,b,turn);
         }
         else if (pos==4)
         {
         Chessboard.board[a][b]=new Knight(a,b,turn);
         }
         
         Chessboard.promotion=false; 
         ChessPanel.updateBoard(); 
         reset();     
      }
   }
   
   
}