import javax.swing.JFrame;

public class ChessDriver{
   public static void main(String[] args) throws Exception
   {
      JFrame frame = new JFrame("Chess");
      frame.setSize(496, 496);
      frame.setLocation(0, 0);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setContentPane(new ChessPanel());
      frame.setVisible(true);
      JFrame rules = new JFrame("Rules");
      rules.setSize(496, 496);
      rules.setLocation(500, 0);
      rules.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
      rules.setContentPane(new RulesPanel());
      rules.setVisible(true);
   }
}