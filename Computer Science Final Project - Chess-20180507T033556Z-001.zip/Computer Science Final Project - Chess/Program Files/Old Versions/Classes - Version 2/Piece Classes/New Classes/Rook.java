import java.util.*;

public class Rook{
   String position;
   String color;
   boolean firstMove;
   ArrayList<String> availableSquares;
   public Rook(int a, int b){
      position = Integer.toString(a) + " " + Integer.toString(b);
      this.color = color;
      firstMove = true;
      availableSquares = new ArrayList<String>(4);
   }
   public boolean check(int a, int b){
      if(availableSquares.contains(Integer.toString(a) + " " = Integer.toString(b))){
         return true;
      }
      return false;
   }
   public void addSquare(int a, int b){
      availableSquares.add(Integer.toString(a) + " " + Integer.toString(b));
   }
   
}