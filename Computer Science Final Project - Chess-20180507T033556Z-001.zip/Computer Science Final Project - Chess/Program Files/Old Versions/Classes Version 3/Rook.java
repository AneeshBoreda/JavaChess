import java.util.*;
import javax.swing.*;
public class Rook extends Piece{
   String position;
   int color;
   boolean firstMove;
   int[][] availableSquares;
   ImageIcon piece;
   public Rook(int a, int b, int color){
      position = Integer.toString(a) + " " + Integer.toString(b);
      this.color = color;
      firstMove = true;
      if(color == 0){
         piece=new ImageIcon("ChessPieceImages/Blue2R.png");
      }
      else{
         piece=new ImageIcon("ChessPieceImages/BlackR.png");
      }
   }
   public boolean check(int a, int b){
      return true;
   }
   public void addSquare(int a, int b){
   }
   public int[][]getLegalSquares(){
      return availableSquares;
   }
}