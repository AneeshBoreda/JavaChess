import java.util.*;

public class Chessboard{
   public static Piece[][] board;
   public static int[] clickLoc;
   public static boolean pieceSelected;
   public Chessboard(){
     // board=x;
   
   }
   public static Piece[][] Input(int a, int b)
   {
     
      if(clickLoc==null&&getPiece(a,b)!=null)
      {
         pieceSelected=true;
         clickLoc = new int[] {a,b};
      }
      else if (pieceSelected)
      {
         board[clickLoc[0]][clickLoc[1]].move(a,b);
         ChessPanel.updateBoard();
         clickLoc=null;
         pieceSelected=false;
      }
      return board;
   }
   public static Piece getPiece(int a, int b)
   {
      return board[a][b];
   }
  
}