import java.util.*;


public class Chessboard{
   public static Piece[][] board;
   public static int[] clickLoc;
   public static boolean pieceSelected;
   public static int[][] legalSquares;
   public static int turn=0;
   public Chessboard(){
     // board=x;
   
   }
   public static Piece[][] Input(int a, int b)
   {
     
      if(clickLoc==null&&getPiece(a,b)!=null)
      {
         if(getPiece(a,b).col==turn){
            pieceSelected=true;
            clickLoc = new int[] {a,b};
            ChessPanel.board[a][b].setBackground(ChessPanel.selectedCol);
            //legalSquares=board[a][b].getLegalSquares());
            //highLightLegalSquares(legalSquares);
         }
         else
         {
            System.out.println("It is the other color's turn.");
            //replace with message saying it isn't that color's turn
         }
         
         
      }
      else if (pieceSelected)
      {
         if(a==clickLoc[0] && b==clickLoc[1])
         {
            ChessPanel.resetColor(clickLoc[0],clickLoc[1]);
            pieceSelected=false;
            clickLoc=null;
            //resetLegalSquares(legalSquares);
         
         }
         else
         {
            board[clickLoc[0]][clickLoc[1]].move(a,b);
            ChessPanel.resetColor(clickLoc[0],clickLoc[1]);
            ChessPanel.updateBoard();
            clickLoc=null;
            pieceSelected=false;
             //resetLegalSquares(legalSquares);
            if(turn==0)
            {
               turn=1;
            }
            else
            {
               turn=0;
            }
         }
      }
      return board;
   }
   public static Piece getPiece(int a, int b)
   {
      return board[a][b];
   }
   public static void highlightLegalSquares(int[][] legalSquares)
   {
      for(int[] x:legalSquares)
      {
         ChessPanel.board[x[0]][x[1]].setBackground(ChessPanel.selectedCol);
      }  
   }
   public static void resetLegalSquares(int[][] legalSquares)
   {
      for(int[] x:legalSquares)
      {
         ChessPanel.resetColor(x[0],x[1]);
      }  
   }
  
}