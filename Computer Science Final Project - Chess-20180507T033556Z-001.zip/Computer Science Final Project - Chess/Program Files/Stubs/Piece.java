import java.util.*;
import javax.swing.*;

public abstract class Piece{
   protected int a;
   protected int b;
   protected int col;
   protected ImageIcon piece;
   public boolean firstMove;
   public Piece(int a, int b, int col){}
   public abstract Stack<int[]> getLegalSquares();
   public abstract ImageIcon getImage();
   public void move(int a, int b){}
}