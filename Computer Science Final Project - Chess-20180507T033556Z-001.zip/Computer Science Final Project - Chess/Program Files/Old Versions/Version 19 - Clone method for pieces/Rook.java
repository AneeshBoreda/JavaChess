import java.util.*;
import javax.swing.*;
public class Rook extends Piece{



   public Stack<int[]> availableSquares;
   public ImageIcon piece;
   public Rook(int a, int b, int color){
      super(a,b,color);
      name = "Rook";
      firstMove = true;
      if(color == 0){
         this.piece=new ImageIcon("ChessPieceImages/Blue2R.png");
      }
      else{
         this.piece=new ImageIcon("ChessPieceImages/BlackR.png");
      }
   }
   public void clonePiece(Piece x)
   {
      this.a = x.a;
      this.b = x.b;
      this.firstMove=x.firstMove;
      this.col=x.col;
      this.piece=x.piece;
      this.name="Rook";
      this.justMoved = x.justMoved;
   }
   public boolean check(int a, int b){
      return true;
   }
   public void addSquare(int a, int b){
   }
   public ImageIcon getImage(){
      return piece;
   }
   public Stack<int[]> getAttackedSquares(){
      availableSquares=new Stack<>();
      for(int k = 1; k < 8; k++){
         if(a+k > 7){
            break;
         }
         if(Chessboard.board[a+k][b] != null){
            availableSquares.push(new int[]{a+k, b});
            
            if(!Chessboard.board[a+k][b].name.equals("King") || Chessboard.board[a+k][b].col==this.col)
            {
            break;
            }
            else{
               availableSquares.pop();
            }

         }
        
         availableSquares.push(new int[]{a+k, b});
      }
      for(int k = 1; k < 8; k++){
         if(a-k < 0){
            break;
         }
         if(Chessboard.board[a-k][b] != null){
            availableSquares.push(new int[]{a-k, b});
            if(!Chessboard.board[a-k][b].name.equals("King")|| Chessboard.board[a-k][b].col==this.col)
            {
            break;
            }
            else{
               availableSquares.pop();
            }
         }
         
         availableSquares.push(new int[]{a-k, b});
      }
      for(int k = 1; k < 8; k++){
         if(b+k > 7){
            break;
         }
         if(Chessboard.board[a][b+k] != null){
            availableSquares.push(new int[]{a, b+k});
            

            if(!Chessboard.board[a][b+k].name.equals("King")|| Chessboard.board[a][b+k].col==this.col)
            {
            break;
            }
            else{
               availableSquares.pop();
            }
         }
         
         availableSquares.push(new int[]{a, b+k});
      }
      for(int k = 1; k < 8; k++){
         if(b-k < 0){
            break;
         }
         if(Chessboard.board[a][b-k] != null){
            availableSquares.push(new int[]{a, b-k});
            if(!Chessboard.board[a][b-k].name.equals("King")|| Chessboard.board[a][b-k].col==this.col)
            {
            break;
            }
            else{
               availableSquares.pop();
            }
         }
         
         availableSquares.push(new int[]{a, b-k});
      }
      
      return availableSquares;
   
   }
   public Stack<int[]> getLegalSquares(){
      availableSquares = new Stack<int[]>();
      for(int k = 1; k < 8; k++){
         if(a+k > 7){
            break;
         }
         if(Chessboard.board[a+k][b] != null && Chessboard.board[a+k][b].col == -1*(col-1)){
            availableSquares.push(new int[]{a+k, b});
            break;
         }
         else if(Chessboard.board[a+k][b] != null){
            break;
         }
         availableSquares.push(new int[]{a+k, b});
      }
      for(int k = 1; k < 8; k++){
         if(a-k < 0){
            break;
         }
         if(Chessboard.board[a-k][b] != null && Chessboard.board[a-k][b].col == -1*(col-1)){
            availableSquares.push(new int[]{a-k, b});
            break;
         }
         else if(Chessboard.board[a-k][b] != null){
            break;
         }
         availableSquares.push(new int[]{a-k, b});
      }
      for(int k = 1; k < 8; k++){
         if(b+k > 7){
            break;
         }
         if(Chessboard.board[a][b+k] != null && Chessboard.board[a][b+k].col == -1*(col-1)){
            availableSquares.push(new int[]{a, b+k});
            break;
         }
         else if(Chessboard.board[a][b+k] != null){
            break;
         }
         availableSquares.push(new int[]{a, b+k});
      }
      for(int k = 1; k < 8; k++){
         if(b-k < 0){
            break;
         }
         if(Chessboard.board[a][b-k] != null && Chessboard.board[a][b-k].col == -1*(col-1)){
            availableSquares.push(new int[]{a, b-k});
            break;
         }
         else if(Chessboard.board[a][b-k] != null){
            break;
         }
         availableSquares.push(new int[]{a, b-k});
      }
      
      return availableSquares;
   }
}