import java.util.*;
import javax.swing.*;
public class Queen extends Piece{
   
 
   public Stack<int[]> availableSquares;
   public ImageIcon piece;
   public Queen(int a, int b, int color){
      super(a,b,color);
      name = "Queen";
      firstMove = true;
      if(color == 0){
         this.piece=new ImageIcon("ChessPieceImages/Blue2Q.png");
      }
      else{
         this.piece=new ImageIcon("ChessPieceImages/BlackQ.png");
      }
   }
   public boolean check(int a, int b){
      return true;
   }
   public void addSquare(int a, int b){
   }
   public ImageIcon getImage(){
      return piece;
   }
   public Stack<int[]> getLegalSquares(){
      availableSquares = new Stack<int[]>();
      int l;
      for(int k = 1; k < 8; k++){
         l = k;
         if(a+k > 7 || b+l > 7){
            break;
         }
         if(Chessboard.board[a+k][b+l] != null && Chessboard.board[a+k][b+l].col == -1*(col-1)){
            availableSquares.push(new int[]{a+k, b+l});
            break;
         }
         else if(Chessboard.board[a+k][b+l] != null){
            break;
         }
         availableSquares.push(new int[]{a+k, b+l});
      }
      for(int k = 1; k < 8; k++){
         l = k;
         if(a-k < 0 || b-l < 0){
            break;
         }
         if(Chessboard.board[a-k][b-l] != null && Chessboard.board[a-k][b-l].col == -1*(col-1)){
            availableSquares.push(new int[]{a-k, b-l});
            break;
         }
         else if(Chessboard.board[a-k][b-l] != null){
            break;
         }
         availableSquares.push(new int[]{a-k, b-l});
      }
      for(int k = 1; k < 8; k++){
         l = -k;
         if(a+k > 7 || b+l < 0){
            break;
         }
         if(Chessboard.board[a+k][b+l] != null && Chessboard.board[a+k][b+l].col == -1*(col-1)){
            availableSquares.push(new int[]{a+k, b+l});
            break;
         }
         else if(Chessboard.board[a+k][b+l] != null){
            break;
         }
         availableSquares.push(new int[]{a+k, b+l});
      }
      for(int k = 1; k < 8; k++){
         l = -k;
         if(a-k < 0 || b-l > 7){
            break;
         }
         if(Chessboard.board[a-k][b-l] != null && Chessboard.board[a-k][b-l].col == -1*(col-1)){
            availableSquares.push(new int[]{a-k, b-l});
            break;
         }
         else if(Chessboard.board[a-k][b-l] != null){
            break;
         }
         availableSquares.push(new int[]{a-k, b-l});
      }
      for(int k = 1; k < 8; k++){
         if(a+k > 7){
            break;
         }
         if(Chessboard.board[a+k][b] != null && Chessboard.board[a+k][b].col == -1*(col-1)){
            availableSquares.push(new int[]{a+k, b});
            break;
         }
         else if(Chessboard.board[a+k][b] != null){
            break;
         }
         availableSquares.push(new int[]{a+k, b});
      }
      for(int k = 1; k < 8; k++){
         if(a-k < 0){
            break;
         }
         if(Chessboard.board[a-k][b] != null && Chessboard.board[a-k][b].col == -1*(col-1)){
            availableSquares.push(new int[]{a-k, b});
            break;
         }
         else if(Chessboard.board[a-k][b] != null){
            break;
         }
         availableSquares.push(new int[]{a-k, b});
      }
      for(int k = 1; k < 8; k++){
         if(b+k > 7){
            break;
         }
         if(Chessboard.board[a][b+k] != null && Chessboard.board[a][b+k].col == -1*(col-1)){
            availableSquares.push(new int[]{a, b+k});
            break;
         }
         else if(Chessboard.board[a][b+k] != null){
            break;
         }
         availableSquares.push(new int[]{a, b+k});
      }
      for(int k = 1; k < 8; k++){
         if(b-k < 0){
            break;
         }
         if(Chessboard.board[a][b-k] != null && Chessboard.board[a][b-k].col == -1*(col-1)){
            availableSquares.push(new int[]{a, b-k});
            break;
         }
         else if(Chessboard.board[a][b-k] != null){
            break;
         }
         availableSquares.push(new int[]{a, b-k});
      }
      
      return availableSquares;
   }
}