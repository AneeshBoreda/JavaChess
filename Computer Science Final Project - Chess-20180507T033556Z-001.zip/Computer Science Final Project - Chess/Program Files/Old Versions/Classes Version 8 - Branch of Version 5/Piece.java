import java.util.*;
import javax.swing.*;
public abstract class Piece{
   protected int a;
   protected int b;
   protected int col;
   protected ImageIcon piece;
   
   public Piece(int a, int b, int col)
   {
      this.a=a;
      this.b=b;
      this.col=col;
   }
   //every piece must move
   //public abstract void move();
   
   //check if piece can move legally
   //public abstract boolean canMove();
   
   //if piece is captured
  // public abstract void captured();
   
   //get legal squares
   //public abstract int[][] getLegalSquares();
   public abstract ImageIcon getImage();
   
   public void move(int a, int b)
   {
      Piece x = Chessboard.board[this.a][this.b];
      Chessboard.board[this.a][this.b]=null;
      Chessboard.board[a][b]=x;      
      this.a=a;
      this.b=b;
      
   }
}