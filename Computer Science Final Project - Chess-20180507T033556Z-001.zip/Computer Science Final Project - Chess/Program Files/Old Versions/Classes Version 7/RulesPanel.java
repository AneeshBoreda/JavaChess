import javax.swing.*;

public class RulesPanel extends JPanel
{
   public RulesPanel()
   {        
      
   }
      
}
