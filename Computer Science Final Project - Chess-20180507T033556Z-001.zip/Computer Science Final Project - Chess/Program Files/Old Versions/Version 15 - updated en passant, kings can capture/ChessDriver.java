import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class ChessDriver{
   public static void main(String[] args) throws IOException
   {
      JFrame frame = new JFrame("Chess");
      frame.setSize(496, 496);
      frame.setLocation(0, 0);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setContentPane(new ChessPanel());
      frame.setVisible(true);
      JFrame rules = new JFrame("Rules");
      rules.setSize(600, 700);
      rules.setLocation(500, 0);
      rules.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      rules.setContentPane(new RulesPanel());
      rules.setVisible(true);
   }
}