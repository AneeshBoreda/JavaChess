import java.util.*;
import java.awt.*;

public class Chessboard
{
   public static Piece[][] board;
   public static int[] clickLoc;
   public static boolean pieceSelected;
   public static Stack<int[]> legalSquares;
   public static int[][]legalSquaresArr;
   public static int turn=0;
   public Chessboard(){}
   public static Piece[][] Input(int a, int b)
   {
      if(clickLoc==null&&getPiece(a,b)!=null)
      {
         if(getPiece(a,b).col==turn)
         {
            legalSquares=board[a][b].getLegalSquares();
            highlightLegalSquares(legalSquaresArr);
         }
         else{}
      }
      else if(pieceSelected)
      {
         if(a==clickLoc[0] && b==clickLoc[1])
         {
            resetLegalSquares(legalSquaresArr);
         }
         else
         {
            boolean contains = false;
            if(contains == true)
            {
               board[clickLoc[0]][clickLoc[1]].move(a,b);
               ChessPanel.resetColor(clickLoc[0],clickLoc[1]);
               ChessPanel.updateBoard();
               resetLegalSquares(legalSquaresArr);
            }
            else{}
         }
      }
      return null;
   }
   public static Piece getPiece(int a, int b)
   {
      return null;
   }
   public static void highlightLegalSquares(int[][]legalSquares){}
   public static void resetLegalSquares(int[][]legalSquares)
   {
      for(int[]x:legalSquares)
      {
         ChessPanel.resetColor(x[0],x[1]);
      }
   }
}