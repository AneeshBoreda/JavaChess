import java.util.*;
import javax.swing.*;
public class Bishop extends Piece{
   String position;
 
   boolean firstMove;
   int[][] availableSquares;
   public ImageIcon piece;
   public Bishop(int a, int b, int color){
      super(a,b,color);
      firstMove = true;
      if(color == 0){
         this.piece=new ImageIcon("ChessPieceImages/Blue2B.png");
      }
      else{
         this.piece=new ImageIcon("ChessPieceImages/BlackB.png");
      }
   }
   public boolean check(int a, int b){
      return true;
   }
   public void addSquare(int a, int b){
   }
   public ImageIcon getImage(){
      return piece;
   }
   public int[][]getLegalSquares(){
      return availableSquares;
   }
}