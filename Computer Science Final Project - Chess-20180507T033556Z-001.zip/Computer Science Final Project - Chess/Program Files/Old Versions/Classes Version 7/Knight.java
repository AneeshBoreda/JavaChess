import java.util.*;
import javax.swing.*;
public class Knight extends Piece{
   String position;
   int color;
   boolean firstMove;
   int[][] availableSquares;
   public ImageIcon piece;
   public String name;
   public Knight(int a, int b, int color){
      super(a,b,color);
      firstMove = true;
      name = "Knight";
      availableSquares = new int[][] {{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1}};
      if(color == 0){
         this.piece=new ImageIcon("ChessPieceImages/Blue2N.png");
      }
      else{
         this.piece=new ImageIcon("ChessPieceImages/BlackN.png");
      }
   }
   public boolean check(int a, int b){
      return true;
   }
   public void addSquare(int a, int b, int num){
      availableSquares[num][0] = a;
      availableSquares[num][1] = b;
   }    
   public ImageIcon getImage(){
      return piece;
   }
   public int[][]getLegalSquares(){
      return availableSquares;
   }
   public String getName(){
      return name;
   }
   public void clearSquares(){
      for(int[] i: availableSquares){
         i[0] = -1;
         i[1] = -1;
      }
   }
}