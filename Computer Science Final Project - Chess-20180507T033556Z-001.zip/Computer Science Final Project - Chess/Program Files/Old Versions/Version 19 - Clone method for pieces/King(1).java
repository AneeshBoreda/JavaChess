import java.util.*;
import javax.swing.*;
import java.lang.*;
public class King extends Piece{
  
   public Stack<int[]> availableSquares;
   public ImageIcon piece;
   public King(int a, int b, int color){
      super(a,b,color);
      name="King";
      firstMove = true;
      if(color == 0){
         this.piece=new ImageIcon("ChessPieceImages/Blue2K.png");
      }
      else{
         this.piece=new ImageIcon("ChessPieceImages/BlackK.png");
      }
   }
   public void clonePiece(Piece x)
   {
      this.a=x.a;
      this.b=x.b;
      this.firstMove=x.firstMove;
      this.col=x.col;
      this.piece=x.piece;
      this.name="King";
      this.justMoved = x.justMoved;
      this.castling = x.castling;
      
   }
   public boolean check(int a, int b){
      return true;
   }
   public void addSquare(int a, int b){
   }
   public ImageIcon getImage(){
      return piece;
   }
   public void move(int a, int b, Piece[][] board)
   {
      Piece x = board[this.a][this.b];
      board[this.a][this.b]=null;
      board[a][b]=x;
      int oldA=this.a;  
      int oldB=this.b;    
      this.a=a;
      this.b=b;
      

      if(castling){
         if(Math.abs(oldB-this.b)==2)
         {
            
            if(this.b>3)
            {
               board[this.a][this.b-1]=board[this.a][this.b+1];
               board[this.a][this.b-1].b=this.b-1;
               board[this.a][this.b+1]=null;
            }
            else
            {
               board[this.a][this.b+1]=board[this.a][this.b-2];
               board[this.a][this.b+1].b=this.b+1;
               board[this.a][this.b-2]=null;
            }
         }
      }
      if(this.firstMove)
      {
         
         justMoved=true;
         this.firstMove=false;
         
      }
      
      lastMoved[0]=a;
      lastMoved[1]=b;
   }  
   public Stack<int[]> getAttackedSquares(Piece[][] board){
      availableSquares=new Stack<>();
      int k = Math.max(0,a-1);
      int l=  Math.min(7,a+1);
      int m=  Math.max(0,b-1);
      int n=  Math.min(7,b+1);
   
      
      for(int i = k; i<=l; i++)
      {  
         for(int j = m; j<=n; j++)
         {
            
            if(i==a && j==b){
               continue;
            }
           
            availableSquares.push(new int[]{i,j});
           
           
         }
      
      }
      return availableSquares;
   }
    public Stack<int[]> getLegalSquares(Piece[][] board){
      availableSquares=new Stack<>();
      int k = Math.max(0,a-1);
      int l=  Math.min(7,a+1);
      int m=  Math.max(0,b-1);
      int n=  Math.min(7,b+1);
   
      for(int i = k; i<=l; i++)
      {  
         for(int j = m; j<=n; j++)
         {
            if(i==a && j==b){
               continue;
            }
            boolean containsB = false;
            boolean containsW = false;
            /***for(int[] p: blackSquares){
               if(p[0] == i && p[1] == j){
                  containsB = true;
                  break;
               }
            }
            for(int[] p: whiteSquares){
               if(p[0] == i && p[1] == j){
                  containsW = true;
                  break;
               }
            }***/
            if(board[i][j]==null)
            {
               if((col == 0 && !(containsB)) || (col == 1 && !(containsW))){
                  availableSquares.push(new int[]{i,j});
               }
            }
            else if(board[i][j].col != this.col)
            {
               if((col == 0 && !(containsB)) || col == 1 && !(containsW)){
                  availableSquares.push(new int[]{i,j});
               }
            }
         }
      
      }
      if(this.firstMove)
      {
         if(b < 5){
            if(board[this.a][this.b+3] != null && board[this.a][this.b+2]==null
            && board[this.a][this.b+1]==null )
            {
               if(board[this.a][this.b+3].firstMove)
               {
                  availableSquares.push(new int[]{this.a, this.b+2});
                  castling=true;
               }
            }
         }
         if(b > 3){
            if(board[this.a][this.b-4] != null && board[this.a][this.b-2]==null
            && board[this.a][this.b-1]==null && board[this.a][this.b-3]==null
            )
            {
               if(board[this.a][this.b-4].firstMove)
               {
                  availableSquares.push(new int[]{this.a, this.b-2});
                  castling=true;
               }
            }
         }
      }
      
      return availableSquares;
   }
}