import java.util.*;
import javax.swing.*;
public class King extends Piece{
   String position;
   int color;
   boolean firstMove;
   int[][] availableSquares;
   public ImageIcon piece;
   public King(int a, int b, int color){
      super(a,b,color);
      firstMove = true;
      if(color == 0){
         this.piece=new ImageIcon("ChessPieceImages/Blue2K.png");
      }
      else{
         this.piece=new ImageIcon("ChessPieceImages/BlackK.png");
      }
   }
   public boolean check(int a, int b){
      return true;
   }
   public void addSquare(int a, int b){
   }
   public ImageIcon getImage(){
      return piece;
   }
   public int[][]getLegalSquares(){
      return availableSquares;
   }
}