import java.util.*;
import javax.swing.*;
public class Pawn extends Piece{
   
   public Stack<int[]> availableSquares;
   public ImageIcon piece;
   private boolean justMoved;
   public Pawn(int a, int b, int color){
      super(a,b,color);
      firstMove = true;
      justMoved = false;
      enPassant = new int[] {-1,-1};
      name = "Pawn";
      if(color == 0){
         this.piece=new ImageIcon("ChessPieceImages/Blue2P.png");
      }
      else{
         this.piece=new ImageIcon("ChessPieceImages/BlackP.png");
      }
     
   }
   public boolean check(int a, int b){
      return true;
   }
   public void addSquare(int a, int b){
      
   }
   public ImageIcon getImage(){
      return piece;
   }
   
   public Stack<int[]> getLegalSquares(){
      enPassant[0] = -1;
      enPassant[1] = -1;
      availableSquares=new Stack<>();
      if (col==0){
         if(Chessboard.board[a-1][b]==null)
         {
            availableSquares.push(new int[]{a-1,b});
            if (firstMove&&Chessboard.board[a-2][b]==null){
            
               availableSquares.push(new int[]{a-2,b});
            }
         }
         if(b<7 && Chessboard.board[a-1][b+1]!=null)
         {
            if(Chessboard.board[a-1][b+1].col==1)
            {
               availableSquares.push(new int[]{a-1,b+1});
            }
            
         }
         if(b>0 && Chessboard.board[a-1][b-1]!=null)
         {
            
            
            if(Chessboard.board[a-1][b-1].col==1)
            {
               availableSquares.push(new int[]{a-1,b-1});
            }
            
            
         }
         if(a==3 && Chessboard.board[a][b+1] != null && b < 7){
            if(Chessboard.board[a][b+1].col == 1 && Chessboard.board[a][b+1].name.equals("Pawn") && 
               Chessboard.board[a][b+1].justMoved == true){
               availableSquares.push(new int[] {a-1,b+1});
               enPassant[0] = a;
               enPassant[1] = b+1;
            }
         }
         if(a==3 && Chessboard.board[a][b-1] != null && b > 0){
            if(Chessboard.board[a][b-1].col == 1 && Chessboard.board[a][b-1].name.equals("Pawn") && 
               Chessboard.board[a][b-1].justMoved == true){
               availableSquares.push(new int[] {a-1,b-1});
               enPassant[0] = a;
               enPassant[1] = b-1;
            }
         }
         
      }
      else{
         if(Chessboard.board[a+1][b]==null)
         {
            availableSquares.push(new int[]{a+1,b});
            if (firstMove&&Chessboard.board[a+2][b]==null){
            
               availableSquares.push(new int[]{a+2,b});
            }
         }
         if(b<7 && Chessboard.board[a+1][b+1]!=null)
         {
            if(Chessboard.board[a+1][b+1].col==0)
            {
               availableSquares.push(new int[]{a+1,b+1});
            }
            
         }
         if(b>0 && Chessboard.board[a+1][b-1]!=null)
         {
         
            if(Chessboard.board[a+1][b-1].col==0)
            {
               availableSquares.push(new int[]{a+1,b-1});
            }
            
            
         }
         if(a==4 && Chessboard.board[a][b+1] != null && b < 7){
            if(Chessboard.board[a][b+1].col == 0 && Chessboard.board[a][b+1].name.equals("Pawn") && 
               Chessboard.board[a][b+1].justMoved == true){
               availableSquares.push(new int[] {a+1,b+1});
               enPassant[0] = a;
               enPassant[1] = b+1;
            }
            
         }
         if(a==4 && Chessboard.board[a][b-1] != null && b > 0){
            if(Chessboard.board[a][b-1].col == 0 && Chessboard.board[a][b-1].name.equals("Pawn") && 
               Chessboard.board[a][b-1].justMoved == true){
               availableSquares.push(new int[] {a+1,b-1});
               enPassant[0] = a;
               enPassant[1] = b+1;
            }
         }
      }
      
      return availableSquares;
   }
}
      
