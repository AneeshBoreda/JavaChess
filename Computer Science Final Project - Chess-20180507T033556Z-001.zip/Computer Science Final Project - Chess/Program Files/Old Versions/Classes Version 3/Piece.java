import java.util.*;
public abstract class Piece{
   
   //every piece must move
   //public abstract void move();
   
   //check if piece can move legally
   //public abstract boolean canMove();
   
   //if piece is captured
  // public abstract void captured();
   
   //get legal squares
   //public abstract int[][] getLegalSquares();
   
}