import java.util.*;
import javax.swing.*;
public class Rook extends Piece{



   public Stack<int[]> availableSquares;
   public ImageIcon piece;
   public Rook(int a, int b, int color){
      super(a,b,color);
      name = "Rook";
      firstMove = true;
      if(color == 0){
         this.piece=new ImageIcon("ChessPieceImages/Blue2R.png");
      }
      else{
         this.piece=new ImageIcon("ChessPieceImages/BlackR.png");
      }
   }
   public boolean check(int a, int b){
      return true;
   }
   public void addSquare(int a, int b){
   }
   public ImageIcon getImage(){
      return piece;
   }
   public Stack<int[]> getLegalSquares(){
      availableSquares = new Stack<int[]>();
      for(int k = 1; k < 8; k++){
         if(a+k > 7){
            break;
         }
         if(Chessboard.board[a+k][b] != null && Chessboard.board[a+k][b].col == -1*(col-1)){
            availableSquares.push(new int[]{a+k, b});
            break;
         }
         else if(Chessboard.board[a+k][b] != null){
            break;
         }
         availableSquares.push(new int[]{a+k, b});
      }
      for(int k = 1; k < 8; k++){
         if(a-k < 0){
            break;
         }
         if(Chessboard.board[a-k][b] != null && Chessboard.board[a-k][b].col == -1*(col-1)){
            availableSquares.push(new int[]{a-k, b});
            break;
         }
         else if(Chessboard.board[a-k][b] != null){
            break;
         }
         availableSquares.push(new int[]{a-k, b});
      }
      for(int k = 1; k < 8; k++){
         if(b+k > 7){
            break;
         }
         if(Chessboard.board[a][b+k] != null && Chessboard.board[a][b+k].col == -1*(col-1)){
            availableSquares.push(new int[]{a, b+k});
            break;
         }
         else if(Chessboard.board[a][b+k] != null){
            break;
         }
         availableSquares.push(new int[]{a, b+k});
      }
      for(int k = 1; k < 8; k++){
         if(b-k < 0){
            break;
         }
         if(Chessboard.board[a][b-k] != null && Chessboard.board[a][b-k].col == -1*(col-1)){
            availableSquares.push(new int[]{a, b-k});
            break;
         }
         else if(Chessboard.board[a][b-k] != null){
            break;
         }
         availableSquares.push(new int[]{a, b-k});
      }
      
      return availableSquares;
   }
}