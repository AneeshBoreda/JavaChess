import java.util.*;
import javax.swing.*;
public abstract class Piece{
   protected int a;
   protected int b;
   protected int col;
   public static String name = "Piece";
   public boolean justMoved;
   private static int[] lastMoved = new int[]{1,1};
   protected ImageIcon piece;
   public boolean firstMove;
   
   public Piece(int a, int b, int col)
   {
      firstMove=true;
      this.a=a;
      this.b=b;
      this.col=col;
   }
   //every piece must move
   //public abstract void move();
   
   //check if piece can move legally
   //public abstract boolean canMove();
   
   //if piece is captured
  // public abstract void captured();
   
   
   public abstract Stack<int[]> getLegalSquares();
   public abstract ImageIcon getImage();
   
   public void move(int a, int b)
   {
           

      if(lastMoved[0]!=-1)
      {
         Chessboard.board[lastMoved[0]][lastMoved[1]].justMoved=false;
      }
      
      Piece x = Chessboard.board[this.a][this.b];
      Chessboard.board[this.a][this.b]=null;
      Chessboard.board[a][b]=x;      
      this.a=a;
      this.b=b;
      if(firstMove)
      {
         justMoved=true;
         firstMove=false;
      }
      
      lastMoved[0]=a;
      lastMoved[1]=b;
      
      
    
      
      
   }

}