import java.util.*;
import javax.swing.*;
public class Pawn extends Piece{
   
   public Stack<int[]> availableSquares;
   public ImageIcon piece;
   
   public Pawn(int a, int b, int color){
      super(a,b,color);
      firstMove = true;
      justMoved = false;
      enPassant = false;
      name = "Pawn";
      if(color == 0){
         this.piece=new ImageIcon("ChessPieceImages/Blue2P.png");
      }
      else{
         this.piece=new ImageIcon("ChessPieceImages/BlackP.png");
      }
     
   }
   public void clonePiece(Piece x)
   {
      this.a = x.a;
      this.b = x.b;
      this.firstMove=x.firstMove;
      this.col=x.col;
      this.piece=x.piece;
      this.name="Pawn";
      this.justMoved = x.justMoved;
   }
   public boolean check(int a, int b){
      return true;
   }
   public void addSquare(int a, int b){
      
   }
   public ImageIcon getImage(){
      return piece;
   }
   public Stack<int[]> getAttackedSquares(){
      availableSquares = new Stack<>();
      if(col==0)
      {
         if(b<7 )
         {
           
            availableSquares.push(new int[]{a-1,b+1});
            
            
         }
         if(b>0 )
         {
           
            availableSquares.push(new int[]{a-1,b-1});
            
            
         }
      } 
      else if(col==1)
      {
         if(b<7 )
         {
           
            availableSquares.push(new int[]{a+1,b+1});
            
            
         }
         if(b>0 )
         {
           
            availableSquares.push(new int[]{a+1,b-1});
            
            
         }
      } 
      return availableSquares;
   }
   public void move(int a, int b)   {  
      if(lastMoved[0]!=-1)
      {
         Chessboard.board[lastMoved[0]][lastMoved[1]].justMoved=false;
      }
      
      Piece x = Chessboard.board[this.a][this.b];
      Chessboard.board[this.a][this.b]=null;
      Chessboard.board[a][b]=x;
      int oldA=this.a;  
      int oldB=this.b;    
      this.a=a;
      this.b=b;
     
      
      if(Chessboard.board[a][b].enPassant){
         Chessboard.board[oldA][b] = null;
      }
      if(this.col==0 && this.a==0)
      {
         InfoPanel.Promotion(0, this.a, this.b);
         InfoPanel.setInfoMessageText("Please select a piece to promote to.");
         Chessboard.promotion=true;
         
      }
      else if(this.col==1 && this.a==7)
      {
         InfoPanel.Promotion(1, this.a, this.b);
         InfoPanel.setInfoMessageText("Please select a piece to promote to.");
         Chessboard.promotion=true;
         
      }
      else if(firstMove)
      {
         justMoved=true;
         firstMove=false;
      }
      
      lastMoved[0]=a;
      lastMoved[1]=b;
   
   }
   public Stack<int[]> getLegalSquares(){
      enPassant = false;
      
      availableSquares=new Stack<>();
      if (col==0){
         if(Chessboard.board[a-1][b]==null)
         {
            availableSquares.push(new int[]{a-1,b});
            if (firstMove&&Chessboard.board[a-2][b]==null){
            
               availableSquares.push(new int[]{a-2,b});
            }
         }
         if(b<7 && Chessboard.board[a-1][b+1]!=null)
         {
            if(Chessboard.board[a-1][b+1].col==1)
            {
               availableSquares.push(new int[]{a-1,b+1});
            }
            
         }
         if(b>0 && Chessboard.board[a-1][b-1]!=null)
         {
            
            
            if(Chessboard.board[a-1][b-1].col==1)
            {
               availableSquares.push(new int[]{a-1,b-1});
            }
            
            
         }
         if(a==3  && b < 7){
            if(Chessboard.board[a][b+1] != null){
               if(Chessboard.board[a][b+1].col == 1 && Chessboard.board[a][b+1].name.equals("Pawn") && 
               Chessboard.board[a][b+1].justMoved == true){
                  availableSquares.push(new int[] {a-1,b+1});
                  enPassant = true;
               }
            }
         }
         if(a==3 && b > 0){
            if(Chessboard.board[a][b-1] != null){
            
               if(Chessboard.board[a][b-1].col == 1 && Chessboard.board[a][b-1].name.equals("Pawn") && 
               Chessboard.board[a][b-1].justMoved == true){
                  availableSquares.push(new int[] {a-1,b-1});
                  enPassant = true;
               }
            }
         }
         
      }
      else{
         if(Chessboard.board[a+1][b]==null)
         {
            availableSquares.push(new int[]{a+1,b});
            if (firstMove&&Chessboard.board[a+2][b]==null){
            
               availableSquares.push(new int[]{a+2,b});
            }
         }
         if(b<7 && Chessboard.board[a+1][b+1]!=null)
         {
            if(Chessboard.board[a+1][b+1].col==0)
            {
               availableSquares.push(new int[]{a+1,b+1});
            }
            
         }
         if(b>0 && Chessboard.board[a+1][b-1]!=null)
         {
         
            if(Chessboard.board[a+1][b-1].col==0)
            {
               availableSquares.push(new int[]{a+1,b-1});
            }
            
            
         }
         if(a==4  && b < 7){
            if(Chessboard.board[a][b+1] != null)
            {
               if(Chessboard.board[a][b+1].col == 0 && Chessboard.board[a][b+1].name.equals("Pawn") && 
               Chessboard.board[a][b+1].justMoved == true){
                  availableSquares.push(new int[] {a+1,b+1});
                  enPassant = true;
               }
            }
            
         }
         if(a==4 && b > 0){
            if(Chessboard.board[a][b-1] != null)
            {
               if(Chessboard.board[a][b-1].col == 0 && Chessboard.board[a][b-1].name.equals("Pawn") && 
               Chessboard.board[a][b-1].justMoved == true){
                  availableSquares.push(new int[] {a+1,b-1});
                  enPassant = true;
               }
            }
         }
      }
      
      return availableSquares;
   }
}
      
