import javax.swing.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class RulesPanel extends JPanel
{
   private JTextArea label;
   private JButton nextButton, prevButton;
   private JLabel textArea;
   private ImageIcon image;
   private String x;
   private String[] text;
   private int page = 0;
   public RulesPanel() throws IOException{}
   private class PrevListener implements ActionListener
   {
      public PrevListener(){}
      public void actionPerformed(ActionEvent e)
      {
         splitLines(label, page);
      }
   }
   private class NextListener implements ActionListener{
      public NextListener(){}
      public void actionPerformed(ActionEvent e)
      {
         splitLines(label, page);
      }
   }
   public void splitLines(JTextArea JTA, int line) {}
}