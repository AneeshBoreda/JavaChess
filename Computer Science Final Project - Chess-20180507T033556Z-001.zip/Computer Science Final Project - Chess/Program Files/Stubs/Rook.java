import java.util.*;
import javax.swing.*;

public class Rook extends Piece{
   String position;
   boolean firstMove;
   public Stack<int[]> availableSquares;
   public ImageIcon piece;
   public Rook(int a, int b, int color)
   {
      super(a, b, color);
   }
   public boolean check(int a, int b)
   {
      return false;
   }
   public void addSquare(int a, int b){}
   public Stack<int[]> getLegalSquares()
   {
      return null;
   }
   public ImageIcon getImage()
   {
      return null;
   }
}