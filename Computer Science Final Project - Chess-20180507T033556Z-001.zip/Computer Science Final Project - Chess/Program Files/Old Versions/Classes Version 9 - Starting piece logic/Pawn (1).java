import java.util.*;
import javax.swing.*;
public class Pawn extends Piece{
   String position;
   
   
   public Stack<int[]> availableSquares;
   public ImageIcon piece;
   public Pawn(int a, int b, int color){
      super(a,b,color);
      firstMove = true;
      if(color == 0){
         this.piece=new ImageIcon("ChessPieceImages/Blue2P.png");
      }
      else{
         this.piece=new ImageIcon("ChessPieceImages/BlackP.png");
      }
   }
   public boolean check(int a, int b){
      return true;
   }
   public void addSquare(int a, int b){
      
   }
   public ImageIcon getImage(){
      return piece;
   }
   public int[][] getLegalSquares(){
      availableSquares=new Stack<>();
      if (col==0){
         if(Chessboard.board[a-1][b]==null)
         {
         availableSquares.push(new int[]{a-1,b});
            if (firstMove&&Chessboard.board[a-2][b]==null){
            
               availableSquares.push(new int[]{a-2,b});
            }
         }
         
      }
      while(!availableSquares.empty()){
      System.out.println(Arrays.toString(availableSquares.pop()));
      }
      return new int[1][1];
   }
}
      
   