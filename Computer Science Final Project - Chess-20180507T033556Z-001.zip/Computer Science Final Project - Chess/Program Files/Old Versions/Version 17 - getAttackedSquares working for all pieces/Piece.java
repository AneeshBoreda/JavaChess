import java.util.*;
import javax.swing.*;
import java.lang.Math;
public abstract class Piece{
   protected int a;
   protected int b;
   protected int col;
   public String name;
   public boolean justMoved;
   public static int[] lastMoved = new int[]{1,1};
   public boolean enPassant;
   protected ImageIcon piece;
   public boolean firstMove;
   public boolean castling;
   
   public Piece(int a, int b, int col)
   {
      firstMove=true;
      this.a=a;
      this.b=b;
      this.col=col;
   }
   //every piece must move
   //public abstract void move();
   
   //check if piece can move legally
   //public abstract boolean canMove();
   
   //if piece is captured
  // public abstract void captured();
   
   
   public abstract Stack<int[]> getLegalSquares();
   public abstract ImageIcon getImage();
   public abstract Stack<int[]> getAttackedSquares();
   public void move(int a, int b)   
   {
           
   
      try{
         Chessboard.board[lastMoved[0]][lastMoved[1]].justMoved=false;
      }
      catch(Exception e)
      {}
      
      
      Piece x = Chessboard.board[this.a][this.b];
      Chessboard.board[this.a][this.b]=null;
      Chessboard.board[a][b]=x;
      int oldA=this.a;  
      int oldB=this.b;    
      this.a=a;
      this.b=b;
      
      if(this.firstMove)
      {
         
         justMoved=true;
         this.firstMove=false;
         
      }
      
      lastMoved[0]=a;
      lastMoved[1]=b;
      
      
    
      
      
   }

}