import java.util.*;
import javax.swing.*;
public class Knight extends Piece{
   String position;
 
   boolean firstMove;
   public Stack<int[]> availableSquares;
   public ImageIcon piece;
   public Knight(int a, int b, int color){
      super(a,b,color);
      firstMove = true;
      if(color == 0){
         this.piece=new ImageIcon("ChessPieceImages/Blue2N.png");
      }
      else{
         this.piece=new ImageIcon("ChessPieceImages/BlackN.png");
      }
   }
   public boolean check(int a, int b){
      return true;
   }
   public void addSquare(int a, int b){
   }
   public ImageIcon getImage(){
      return piece;
   }
   public Stack<int[]> getLegalSquares(){
      return availableSquares;
   }
}