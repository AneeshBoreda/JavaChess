import java.util.*;
import javax.swing.*;
public class Knight extends Piece{
   boolean firstMove;
   public Stack<int[]> availableSquares;
   public ImageIcon piece;
   public Knight(int a, int b, int color){
      super(a,b,color);
      firstMove = true;
      if(color == 0){
         this.piece=new ImageIcon("ChessPieceImages/Blue2N.png");
      }
      else{
         this.piece=new ImageIcon("ChessPieceImages/BlackN.png");
      }
   }
   public boolean check(int a, int b){
      return true;
   }
   public void addSquare(int a, int b){
   }
   public ImageIcon getImage(){
      return piece;
   }
   public Stack<int[]> getLegalSquares(){
      availableSquares=new Stack<int[]>();
      for(int k = -2; k < 3; k+=4){
         for(int l = -1; l < 2; l+=2){
            if((a-l > -1 && b-k > -1) && (a-l < 8 && b-k < 8)){
               if(Chessboard.board[a-l][b-k] == null || Chessboard.board[a-l][b-k].col == -1*(col-1)){
                  availableSquares.push(new int[]{a-l,b-k});
               }
            }
            if((a-k > -1 && b-l > -1) && (a-k < 8 && b-l < 8)){
               if(Chessboard.board[a-k][b-l] == null || Chessboard.board[a-k][b-l].col == -1*(col-1)){
                  availableSquares.push(new int[]{a-k,b-l});
               }
            }
         }
      }
      return availableSquares;
   }
}