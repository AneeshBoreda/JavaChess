import java.util.*;
import javax.swing.*;
import java.lang.Math;
public abstract class Piece{
   protected int a;
   protected int b;
   protected int col;
   public String name;
   public boolean justMoved;
   public static int[] lastMoved = new int[]{1,1};
   public boolean enPassant;
   protected ImageIcon piece;
   public boolean firstMove;
   public boolean castling;
   
   public Piece(int a, int b, int col)
   {
      firstMove=true;
      this.a=a;
      this.b=b;
      this.col=col;
   }
  
   public abstract void clonePiece(Piece x);
   
   //check if piece can move legally
   //public abstract boolean canMove();
   
   //if piece is captured
  // public abstract void captured();
   
   
   public abstract Stack<int[]> getLegalSquares(Piece[][] board);
   public abstract ImageIcon getImage();
   public abstract Stack<int[]> getAttackedSquares(Piece[][] board);
   public void move(int a, int b, Piece[][] board)   
   {
           
   
      try{
         board[lastMoved[0]][lastMoved[1]].justMoved=false;
      }
      catch(Exception e)
      {}
      
      
      Piece x = board[this.a][this.b];
      board[this.a][this.b]=null;
      board[a][b]=x;
      int oldA=this.a;  
      int oldB=this.b;    
      this.a=a;
      this.b=b;
      
      if(this.firstMove)
      {
         
         justMoved=true;
         this.firstMove=false;
         
      }
      
      lastMoved[0]=a;
      lastMoved[1]=b;
      
      
    
      
      
   }

}