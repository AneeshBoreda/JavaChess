import java.util.*;
import javax.swing.*;
public class Rook extends Piece{
   String position;
   int color;
   boolean firstMove;
   int[][] availableSquares;
   public ImageIcon piece;
   public String name;
   public Rook(int a, int b, int color){
      super(a,b,color);
      firstMove = true;
      availableSquares = new int[][] {{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1}};
      name = "Rook";
      if(color == 0){
         this.piece=new ImageIcon("ChessPieceImages/Blue2R.png");
      }
      else{
         this.piece=new ImageIcon("ChessPieceImages/BlackR.png");
      }
   }
   public boolean check(int a, int b){
      return true;
   }
   public void addSquare(int a, int b, int num){
      availableSquares[num][0] = a;
      availableSquares[num][1] = b;
   }    
   public ImageIcon getImage(){
      return piece;
   }
   public int[][]getLegalSquares(){
      return availableSquares;
   }
   public String getName(){
      return name;
   }
   public void clearSquares(){
      for(int[] i: availableSquares){
         i[0] = -1;
         i[1] = -1;
      }
   }
}