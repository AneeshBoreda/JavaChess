//Name______________________________ Date_____________
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.awt.Dimension;
public class ChessPanel extends JPanel
{
   private JLabel label1, label2;
   private JTextField box;
   private int number, count;
   private Color col;
   public ChessPanel()
   {
      setLayout(new GridLayout(8, 8));
      number = 37;     //number gets 37
      count = 0;
      JButton[][] board = new JButton[8][8];
      ImageIcon piece=new ImageIcon("ChessPieceImages/BlackB.png");
      for(int i = 0; i < 8; i++){
         for(int j = 0; j < 8; j++){
            board[i][j]=new JButton();
            //Integer.toString(i*8+j+1)Integer.toString(i*8+j+1)
            board[i][j].setFocusPainted(false);
            
            if((i+j)%2==0){
               col=Color.WHITE;
            }
            else{
               col=Color.BLACK;
            }
            board[i][j].setBackground(col);
            board[i][j].setSize(new Dimension(150,150));
            board[i][j].setIcon(piece);
            add(board[i][j]);
         }      
      }
   }
   private class Listener implements ActionListener
   {
      
      public void actionPerformed(ActionEvent e)
      {
      }
   }
   
}
