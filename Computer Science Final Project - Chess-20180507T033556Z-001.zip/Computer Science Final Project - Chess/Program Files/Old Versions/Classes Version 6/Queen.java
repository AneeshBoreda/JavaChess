import java.util.*;
import javax.swing.*;
public class Queen extends Piece{
   String position;
   int color;
   boolean firstMove;
   int[][] availableSquares;
   public ImageIcon piece;
   public String name;
   public Queen(int a, int b, int color){
      super(a,b,color);
      firstMove = true;
      name = "Queen";
      availableSquares = new int[][] {{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1}};
      if(color == 0){
         this.piece=new ImageIcon("ChessPieceImages/Blue2Q.png");
      }
      else{
         this.piece=new ImageIcon("ChessPieceImages/BlackQ.png");
      }
   }
   public boolean check(int a, int b){
      return true;
   }
   public void addSquare(int a, int b, int num){
      availableSquares[num][0] = a;
      availableSquares[num][1] = b;
   }    
   public ImageIcon getImage(){
      return piece;
   }
   public int[][]getLegalSquares(){
      return availableSquares;
   }
   public String getName(){
      return name;
   }
   public void clearSquares(){
      for(int[] i: availableSquares){
         i[0] = -1;
         i[1] = -1;
      }
   }
}