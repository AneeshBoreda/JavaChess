import javax.swing.*;
import java.io.*;
import java.awt.*;
import java.util.*;

public class InfoPanel extends JPanel
{

   private static JLabel label;
  

   public InfoPanel() 
   {
      label = new JLabel("No Messages to Show");
      label.setFont(new Font("Arial", 1, 18));
      add(label);
   }
   public static void setMessageText(String st)
   {
      label.setText(st);
   }
   public static void resetMessageText()
   {
      label.setText("No Messages to Show");
   }
   
   
}