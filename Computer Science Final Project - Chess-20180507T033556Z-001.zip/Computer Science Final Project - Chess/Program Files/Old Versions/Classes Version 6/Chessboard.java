import java.util.*;

public class Chessboard{
   public static Piece[][] board2;
   public static int[] clickLoc;
   public static boolean pieceSelected;
   public Chessboard(){
     // board=x;
   
   }
   public static Piece[][] Input(int a, int b)
   {
     
      if(clickLoc==null&&getPiece(a,b)!=null)
      {
         int[][] legalSquares;
         pieceSelected=true;
         clickLoc = new int[] {a,b};
         ChessPanel.board[a][b].setBackground(ChessPanel.selectedCol);
         legalSquares = ChessPanel.pieces[a][b].getLegalSquares();
         for(int[] i: legalSquares){
            System.out.println(i[0]);
            if(i[0] != -1){
               ChessPanel.board[i[0]][i[1]].setBackground(ChessPanel.legalCol);
            }
         }
      }
      else if (pieceSelected)
      {
         boolean contains = false;
         for(int[] i: ChessPanel.pieces[clickLoc[0]][clickLoc[1]].getLegalSquares()){
            if(a == i[0] && b == i[1]){
               contains = true;
               break;
            }
         }
         if(contains == true){
            board2[clickLoc[0]][clickLoc[1]].move(a,b);
            ChessPanel.updateBoard();
            clickLoc=null;
            pieceSelected=false;
         }else{
            System.out.println("Please choose one of the squares highlighted green.");
         }
      }
      return board2;
   }
   public static Piece getPiece(int a, int b)
   {
      return board2[a][b];
   }
  
}