import java.util.*;

public class Chessboard{
   Piece[][] board;
   public Chessboard(Piece[][] x){
      board=x;
   
   }
}