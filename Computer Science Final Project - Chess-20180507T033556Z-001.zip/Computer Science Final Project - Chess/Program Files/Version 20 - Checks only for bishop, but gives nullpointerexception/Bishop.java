import java.util.*;
import javax.swing.*;
public class Bishop extends Piece{ 

   public Stack<int[]> availableSquares;
   public ImageIcon piece;
   public Bishop(int a, int b, int color){
      super(a,b,color);
      name = "Bishop";
      firstMove = true;
      if(color == 0){
         this.piece=new ImageIcon("ChessPieceImages/Blue2B.png");
      }
      else{
         this.piece=new ImageIcon("ChessPieceImages/BlackB.png");
      }
   }
   public void clonePiece(Piece x)
   {
      this.a = x.a;
      this.b = x.b;
      this.firstMove=x.firstMove;
      this.col=x.col;
      this.piece=x.piece;
      this.name="Bishop";
      this.justMoved = x.justMoved;
   }
   public boolean check(int a, int b){
      return true;
   }
   public void addSquare(int a, int b){
   }
   public ImageIcon getImage(){
      return piece;
   }
   public Stack<int[]> getAttackedSquares(Piece[][] board){
      availableSquares=new Stack<>();
      int l;
      for(int k = 1; k < 8; k++){
         l = k;
         if(a+k > 7 || b+l > 7){
            break;
         }
         if(board[a+k][b+l] != null ){
            availableSquares.push(new int[]{a+k, b+l});
            
            if(!board[a+k][b+l].name.equals("King") || board[a+k][b+l].col==this.col)
            {
               break;
            }
            else{
               availableSquares.pop();
            }
         }
         availableSquares.push(new int[]{a+k, b+l});
      }
      for(int k = 1; k < 8; k++){
         l = k;
         if(a-k < 0 || b-l < 0){
            break;
         }
         if(board[a-k][b-l] != null){
            availableSquares.push(new int[]{a-k, b-l});
            if(!board[a-k][b-l].name.equals("King") || board[a-k][b-l].col==this.col)
            {
               break;
            }
            else{
               availableSquares.pop();
            }
         }
      
         availableSquares.push(new int[]{a-k, b-l});
      }
      for(int k = 1; k < 8; k++){
         l = -k;
         if(a+k > 7 || b+l < 0){
            break;
         }
         if(board[a+k][b+l] != null){
            availableSquares.push(new int[]{a+k, b+l});
            if(!board[a+k][b+l].name.equals("King") || board[a+k][b+l].col==this.col)
            {
               break;
            }
            else{
               availableSquares.pop();
            }
            
         }
        
         availableSquares.push(new int[]{a+k, b+l});
      }
      for(int k = 1; k < 8; k++){
         l = -k;
         if(a-k < 0 || b-l > 7){
            break;
         }
         if(board[a-k][b-l] != null){
            availableSquares.push(new int[]{a-k, b-l});
            if(!board[a-k][b-l].name.equals("King") || board[a-k][b-l].col==this.col)
            {
               break;
            }
            else{
               availableSquares.pop();
            }
         }
         availableSquares.push(new int[]{a-k, b-l});
      }
      return availableSquares;
   }
   public Stack<int[]> getLegalSquares(Piece[][] board){
      availableSquares = new Stack<int[]>();
      int l;
      for(int k = 1; k < 8; k++){
         l = k;
         if(a+k > 7 || b+l > 7){
            break;
         }
         if(board[a+k][b+l] != null && board[a+k][b+l].col == -1*(col-1)){
            availableSquares.push(new int[]{a+k, b+l});
            break;
         }
         else if(board[a+k][b+l] != null){
            break;
         }
         availableSquares.push(new int[]{a+k, b+l});
      }
      for(int k = 1; k < 8; k++){
         l = k;
         if(a-k < 0 || b-l < 0){
            break;
         }
         if(board[a-k][b-l] != null && board[a-k][b-l].col == -1*(col-1)){
            availableSquares.push(new int[]{a-k, b-l});
            break;
         }
         else if(board[a-k][b-l] != null){
            break;
         }
         availableSquares.push(new int[]{a-k, b-l});
      }
      for(int k = 1; k < 8; k++){
         l = -k;
         if(a+k > 7 || b+l < 0){
            break;
         }
         if(board[a+k][b+l] != null && board[a+k][b+l].col == -1*(col-1)){
            availableSquares.push(new int[]{a+k, b+l});
            break;
         }
         else if(board[a+k][b+l] != null){
            break;
         }
         availableSquares.push(new int[]{a+k, b+l});
      }
      for(int k = 1; k < 8; k++){
         l = -k;
         if(a-k < 0 || b-l > 7){
            break;
         }
         if(board[a-k][b-l] != null && board[a-k][b-l].col == -1*(col-1)){
            availableSquares.push(new int[]{a-k, b-l});
            break;
         }
         else if(board[a-k][b-l] != null){
            break;
         }
         availableSquares.push(new int[]{a-k, b-l});
      }
      Piece[][] tmp = Chessboard.cloneBoard();
      
      Stack<int[]> clonedStack=(Stack<int[]>) availableSquares.clone();
      Stack<int[]> finalSquares=new Stack<int[]>();
      
      int[] kingLoc= new int[2];
      for(int q = 0; q<availableSquares.size(); q++)
      {
         System.out.println(clonedStack.toString());
         System.out.println("JKJKJ");
         Chessboard.whiteSquares.clear();
         Chessboard.blackSquares.clear();
         int[] moved=clonedStack.pop();
         System.out.println(Arrays.toString(moved));
         System.out.println("ASDF");
         tmp[a][b].move(moved[0],moved[1],tmp);
         for(int i = 0; i < 8; i++){
            for(int j = 0; j < 8; j++){
               if (tmp[i][j]!=null)
               {
                  Stack<int[]> k;
                  if(tmp[i][j].col == 0 && !(tmp[i][j].name.equals("King"))){
                     k = tmp[i][j].getAttackedSquares(tmp);
                     int p = k.size();
                     for(int z = 0; z < p; z++){
                        Chessboard.whiteSquares.add(k.pop());
                     }
                  }
                  else if(tmp[i][j].col == 1 && !(tmp[i][j].name.equals("King"))){
                     k = tmp[i][j].getAttackedSquares(tmp);
                     int p = k.size();
                     for(int z = 0; z < p; z++){
                        Chessboard.blackSquares.add(k.pop());
                     }
                  }
                  else if(tmp[i][j].col == 0 && tmp[i][j].name.equals("King")){
                     Chessboard.whiteSquares.add(new int[]{i-1,j-1});
                     Chessboard.whiteSquares.add(new int[]{i-1,j});
                     Chessboard.whiteSquares.add(new int[]{i-1,j+1});
                     Chessboard.whiteSquares.add(new int[]{i,j-1});
                     Chessboard.whiteSquares.add(new int[]{i,j+1});
                     Chessboard.whiteSquares.add(new int[]{i+1,j-1});
                     Chessboard.whiteSquares.add(new int[]{i+1,j});
                     Chessboard.whiteSquares.add(new int[]{i+1,j+1});
                     if(this.col==0)
                     {
                        kingLoc=new int[]{i,j};
                     }
                  }
                  else if(tmp[i][j].col == 1 && tmp[i][j].name.equals("King")){
                     Chessboard.blackSquares.add(new int[]{i-1,j-1});
                     Chessboard.blackSquares.add(new int[]{i-1,j});
                     Chessboard.blackSquares.add(new int[]{i-1,j+1});
                     Chessboard.blackSquares.add(new int[]{i,j-1});
                     Chessboard.blackSquares.add(new int[]{i,j+1});
                     Chessboard.blackSquares.add(new int[]{i+1,j-1});
                     Chessboard.blackSquares.add(new int[]{i+1,j});
                     Chessboard.blackSquares.add(new int[]{i+1,j+1});
                     if(this.col==1)
                     {
                        kingLoc=new int[]{i,j};
                     }
                  }
               }
            
               
            }
         }
         boolean contains;
         if(this.col==0)
         {
         for(int[] p: Chessboard.blackSquares){
            if(p[0] == kingLoc[0] && p[1] == kingLoc[1]){
               contains = true;
               break;
            }
         }
         }
         else if(this.col==1)
         {
         for(int[] p: Chessboard.whiteSquares){
            if(p[0] == kingLoc[0] && p[1] == kingLoc[1]){
               contains = true;
               break;
            }
         }
         finalSquares.push(moved);
         }
      }
      return finalSquares;
   }
}
